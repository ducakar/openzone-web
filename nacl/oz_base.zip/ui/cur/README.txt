This is a subset of OpenZone X11 cursor theme. The full theme can be
found at http://opendesktop.org/content/show.php/OpenZone?content=111343
