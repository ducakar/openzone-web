Title:          Essential data for OpenZone engine
Packager:       Davorin Učakar
Contact:        davorin.ucakar@gmail.com
Copyright:      See individual COPYING and README files
Licence:        See individual COPYING and README files
Description:    This is essential package required for OpenZone engine. It standard shaders, fonts,
                mouse cursors, HUD icons, background images and translations for UI elements.
